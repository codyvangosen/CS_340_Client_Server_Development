from pymongo import MongoClient, errors
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ 
    CRUD operations for Animal collection in MongoDB.
    This class provides methods to create, read, update, and delete documents from the 'animals' collection in MongoDB.
    """

    def __init__(self):
        """
        Initialize the connection to the MongoDB database using the provided credentials
        and connection details from the Apporto environment. This method sets up the client
        to communicate with the MongoDB server and connects to the specific database and collection.
        
        Extensive error handling is implemented to ensure that the connection is successfully established.
        """
        # MongoDB Connection Variables: These need to be adjusted to match your Apporto environment
        USER = 'aacuser'  # MongoDB Username
        PASS = '340cjfootball'  # MongoDB Password
        HOST = 'nv-desktop-services.apporto.com'  # MongoDB Host
        PORT = 30036  # MongoDB Port
        DB = 'AAC'  # Database Name
        COL = 'animals'  # Collection Name
        
        # Initialize the MongoDB client connection with extensive error handling
        try:
            # Establish connection to MongoDB using the provided credentials
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}', serverSelectionTimeoutMS=5000)
            self.database = self.client[DB]  # Connect to the specific database
            self.collection = self.database[COL]  # Connect to the specific collection
            
            # Test the connection by triggering a server selection (will raise error if connection fails)
            self.client.server_info()  # Raises an exception if connection fails
            print("MongoDB connection established successfully.")
        
        except errors.ServerSelectionTimeoutError as e:
            # Handle the case where MongoDB server is unreachable within the timeout period
            print(f"Failed to connect to MongoDB server: {e}")
            raise
        
        except errors.OperationFailure as e:
            # Handle authentication errors or other MongoDB-specific errors
            print(f"Authentication failed or operation error: {e}")
            raise
        
        except Exception as e:
            # Generic exception handling for any other unforeseen errors
            print(f"An unexpected error occurred during MongoDB connection: {e}")
            raise

    def create(self, data):
        """
        Create a new document in the MongoDB collection. This method inserts the provided data into the
        'animals' collection of the MongoDB database.
        
        Parameters:
            data (dict): A dictionary containing the key-value pairs representing the document to be inserted.
        
        Returns:
            bool: True if the insertion is successful, False otherwise.
        
        Extensive error handling is implemented to manage edge cases such as:
        - Invalid data types
        - Empty input
        - MongoDB insertion errors
        """
        # Check if the input data is a valid dictionary and not empty
        if data is None:
            raise ValueError("Input data is None. A valid dictionary is required.")
        
        if not isinstance(data, dict):
            raise TypeError("Invalid input type: Data must be a dictionary.")
        
        if len(data) == 0:
            raise ValueError("Input data is empty. Cannot insert an empty document into the database.")
        
        try:
            # Attempt to insert the document into the MongoDB collection
            result = self.collection.insert_one(data)
            
            # Check if the insertion was successful by checking for the presence of an inserted ID
            if result.inserted_id:
                print(f"Document inserted successfully with ID: {result.inserted_id}")
                return True
            else:
                print("Document insertion failed: No ID returned.")
                return False
        
        except errors.DuplicateKeyError as e:
            # Handle the case where the document contains a duplicate key that violates uniqueness
            print(f"Duplicate key error: {e}")
            return False
        
        except errors.OperationFailure as e:
            # Handle any other operation failure errors from MongoDB
            print(f"Operation failure during document insertion: {e}")
            return False
        
        except Exception as e:
            # Generic error handling for any other unforeseen errors
            print(f"An unexpected error occurred during document insertion: {e}")
            return False

    def read(self, query={}):
        """
        Read documents from the MongoDB collection that match the specified query.
        Allow an empty query to retrieve all documents.
        
        Parameters:
            query (dict): A dictionary containing the key-value pairs for the query filter.
                         If no query is provided, all documents will be retrieved.
        
        Returns:
            list: A list of documents matching the query or an empty list if no documents are found.
        
        Extensive error handling is implemented to manage edge cases such as:
        - Invalid query input
        - MongoDB query errors
        """
        # Ensure query is a dictionary
        if not isinstance(query, dict):
            raise TypeError("Invalid query type: Query must be a dictionary.")
        
        try:
            # Execute the query to find matching documents in the MongoDB collection
            documents = list(self.collection.find(query))
            
            if documents:
                print(f"Found {len(documents)} document(s) matching the query.")
                return documents
            else:
                print("No documents found matching the query.")
                return []
        
        except errors.OperationFailure as e:
            # Handle any operation failures during the query execution
            print(f"Operation failure during query: {e}")
            return []
        
        except Exception as e:
            # Generic error handling for any other unforeseen errors
            print(f"An unexpected error occurred during the query: {e}")
            return []

    def update(self, query, update_data):
        """
        Update documents in the MongoDB collection that match the specified query.
        This method modifies the documents that match the given query filter and updates them with the provided update data.
        
        Parameters:
            query (dict): A dictionary containing the key-value pairs for the query filter.
            update_data (dict): A dictionary containing the key-value pairs for the fields to be updated.
        
        Returns:
            int: The number of documents that were modified.
        
        Extensive error handling is implemented to manage edge cases such as:
        - Invalid query or update data input
        - MongoDB update errors
        """
        # Validate the query and update_data inputs
        if query is None or update_data is None:
            raise ValueError("Query and update_data parameters are required.")
        
        if not isinstance(query, dict) or not isinstance(update_data, dict):
            raise TypeError("Both query and update_data must be dictionaries.")
        
        if len(query) == 0 or len(update_data) == 0:
            raise ValueError("Query and update_data cannot be empty.")
        
        try:
            # Perform the update operation in the MongoDB collection
            result = self.collection.update_many(query, {'$set': update_data})
            
            # Return the number of documents that were modified
            print(f"{result.modified_count} document(s) were updated.")
            return result.modified_count
        
        except errors.OperationFailure as e:
            # Handle any MongoDB operation failures during the update process
            print(f"Operation failure during update: {e}")
            return 0
        
        except Exception as e:
            # Generic error handling for any other unforeseen errors
            print(f"An unexpected error occurred during the update operation: {e}")
            return 0

    def delete(self, query):
        """
        Delete documents from the MongoDB collection that match the specified query.
        This method removes all documents that match the given query filter from the 'animals' collection.
        
        Parameters:
            query (dict): A dictionary containing the key-value pairs for the query filter.
        
        Returns:
            int: The number of documents that were deleted.
        
        Extensive error handling is implemented to manage edge cases such as:
        - Invalid query input
        - MongoDB deletion errors
        """
        # Validate the query input
        if query is None:
            raise ValueError("Query parameter is required.")
        
        if not isinstance(query, dict):
            raise TypeError("Query must be a dictionary.")
        
        if len(query) == 0:
            raise ValueError("Query cannot be empty.")
        
        try:
            # Perform the delete operation in the MongoDB collection
            result = self.collection.delete_many(query)
            
            # Return the number of documents that were deleted
            print(f"{result.deleted_count} document(s) were deleted.")
            return result.deleted_count
        
        except errors.OperationFailure as e:
            # Handle any MongoDB operation failures during the deletion process
            print(f"Operation failure during deletion: {e}")
            return 0
        
        except Exception as e:
            # Generic error handling for any other unforeseen errors
            print(f"An unexpected error occurred during the delete operation: {e}")
            return 0
